# ABCD > 2024-06-18 8:54am
https://universe.roboflow.com/aayush-aashish-maheshwari/abcd-jo4rt

Provided by a Roboflow user
License: CC BY 4.0

